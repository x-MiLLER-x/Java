import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FastCollinearPoints {
    private final List<LineSegment> segmentsList = new ArrayList<>();

    public FastCollinearPoints(Point[] points) {
        if (points == null) {
            throw new IllegalArgumentException("Input points array is null");
        }

        int n = points.length;
        Point[] sortedPoints = Arrays.copyOf(points, n);

        for (int i = 0; i < n; i++) {
            if (points[i] == null) {
                throw new IllegalArgumentException("Input contains null points");
            }

            Arrays.sort(sortedPoints);
            Arrays.sort(sortedPoints, points[i].slopeOrder());

            int j = 1;
            while (j < n) {
                int count = 1;
                double currentSlope = points[i].slopeTo(sortedPoints[j]);

                while (j + count < n && Double.compare(currentSlope, points[i].slopeTo(sortedPoints[j + count])) == 0) {
                    count++;
                }

                if (count >= 3 && sortedPoints[0].compareTo(points[i]) < 0) {
                    segmentsList.add(new LineSegment(sortedPoints[0], sortedPoints[j + count - 1]));
                }

                j += count;
            }
        }
    }

    public int numberOfSegments() {
        return segmentsList.size();
    }

    public LineSegment[] segments() {
        return segmentsList.toArray(new LineSegment[0]);
    }
}
