import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.RectHV;
import edu.princeton.cs.algs4.StdDraw;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;

public class PointSET {
    private Set<Point2D> points;

    public PointSET() {
        points = new HashSet<>();
    }

    public boolean isEmpty() {
        return points.isEmpty();
    }

    public int size() {
        return points.size();
    }

    public void insert(Point2D p) {
        if (p == null) {
            throw new IllegalArgumentException("Point cannot be null");
        }
        points.add(p);
    }

    public boolean contains(Point2D p) {
        if (p == null) {
            throw new IllegalArgumentException("Point cannot be null");
        }
        return points.contains(p);
    }

    public void draw() {
        StdDraw.setPenColor(StdDraw.BLACK);
        StdDraw.setPenRadius(0.01);
        for (Point2D point : points) {
            point.draw();
        }
    }

    public Iterable<Point2D> range(RectHV rect) {
        if (rect == null) {
            throw new IllegalArgumentException("Rectangle cannot be null");
        }
        LinkedList<Point2D> rangePoints = new LinkedList<>();
        for (Point2D point : points) {
            if (rect.contains(point)) {
                rangePoints.add(point);
            }
        }
        return rangePoints;
    }

    public Point2D nearest(Point2D p) {
        if (p == null) {
            throw new IllegalArgumentException("Point cannot be null");
        }
        double minDist = Double.POSITIVE_INFINITY;
        Point2D nearest = null;
        for (Point2D point : points) {
            double dist = p.distanceSquaredTo(point);
            if (dist < minDist) {
                minDist = dist;
                nearest = point;
            }
        }
        return nearest;
    }

    public static void main(String[] args) {
        // Example usage and testing
        PointSET pointSet = new PointSET();
        pointSet.insert(new Point2D(0.2, 0.3));
        pointSet.insert(new Point2D(0.4, 0.7));
        pointSet.insert(new Point2D(0.9, 0.6));

        RectHV rangeRect = new RectHV(0.3, 0.2, 0.8, 0.7);
        System.out.println("Points in range:");
        for (Point2D p : pointSet.range(rangeRect)) {
            System.out.println(p);
        }

        Point2D nearestPoint = pointSet.nearest(new Point2D(0.6, 0.5));
        System.out.println("Nearest point: " + nearestPoint);
    }
}
